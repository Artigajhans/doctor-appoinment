const { BookAppointment, getDoctors, getDoctorsById, cancelAppointment, getPatientAppointments } = require("../controller/patients.controller");

const router = require("express").Router()

router

    //patients
    .get("/getAllDotors-patient", getDoctors)
    .get("/getDoctorById/:id", getDoctorsById)
    .post('/patient-bookappointment', BookAppointment)
    .put("/patient-cancelAppoint/:aid", cancelAppointment)
    .get("/patient-getAppoin", getPatientAppointments)


module.exports = router